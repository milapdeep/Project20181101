// JavaScript source code
function loginUser() {
    if (document.getElementById("exampleInputEmail1").value !== '') {
        if (document.getElementById("exampleInputPassword1").value === 'test') {
            document.getElementById("frmLogin").style.display = "none";
            document.getElementById("divLoggedIn").innerHTML = "<div class='alert alert-warning'><span>Welcome back " + document.getElementById("exampleInputEmail1").value + "!</span></div>";
            document.getElementById("divLoggedInFeature").style.display = "block";
            return true;
        } else {
            document.getElementById("divLoggedIn").innerHTML = "<div class='alert alert-danger'><span>Failed! Please try again</span></div>";
        }
    }
}

function exampleCamera() {
    navigator.camera.getPicture(onSuccess, onFail, {
        quality: 50,
        destinationType: Camera.DestinationType.DATA_URL
    });

    function onSuccess(imageData) {
        document.getElementById("divLoggedIn").innerHTML = "<div class='alert alert-info'><span>Success! Loading Image...</span></div>";
        var image = document.getElementById('exampleImage');
        image.src = "data:image/jpeg;base64," + imageData;
    }

    function onFail(message) {
        document.getElementById("divLoggedIn").innerHTML = "<div class='alert alert-danger'><span>Failed because: " + message + "</span></div>";
    } 
}

function examplePicture() {
    navigator.camera.getPicture(onSuccess, onFail, {
        quality: 50,
        destinationType: Camera.DestinationType.DATA_URL,
        sourceType: Camera.PictureSourceType.PHOTOLIBRARY
    });

    function onSuccess(imageURL) {
        document.getElementById("divLoggedIn").innerHTML = "<div class='alert alert-info'><span>Success! Loading Image...</span></div>";
        var image = document.getElementById('exampleImage');
        image.src = imageURL;
    }

    function onFail(message) {
        document.getElementById("divLoggedIn").innerHTML = "<div class='alert alert-danger'><span>Failed because: " + message + "</span></div>";
    }
}
